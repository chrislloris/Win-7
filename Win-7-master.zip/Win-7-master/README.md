------------------
System Information
------------------
Time of this report: 9/2/2015, 19:28:59
       Machine name: MANO-PC
   Operating System: Windows 7 Professional 32-bit (6.1, Build 7601) Service Pack 1 (7601.win7sp1_gdr.150722-0600)
           Language: Lithuanian (Regional Setting: Lithuanian)
System Manufacturer: Acer, inc.
       System Model: Aspire 5920     
               BIOS: ZD1 v1.3811 3H11
          Processor: Intel(R) Core(TM)2 Duo CPU     T5550  @ 1.83GHz (2 CPUs), ~1.8GHz
             Memory: 2048MB RAM
Available OS Memory: 2038MB RAM
          Page File: 2100MB used, 2995MB available
        Windows Dir: C:\Windows
    DirectX Version: DirectX 11
DX Setup Parameters: Not found
   User DPI Setting: Using System DPI
 System DPI Setting: 96 DPI (100 percent)
    DWM DPI Scaling: Disabled
     DxDiag Version: 6.01.7601.17514 32bit Unicode

------------
DxDiag Notes
------------
      Display Tab 1: No problems found.
        Sound Tab 1: No problems found.
        Sound Tab 2: No problems found.
        Sound Tab 3: No problems found.
          Input Tab: No problems found.

--------------------
DirectX Debug Levels
--------------------
Direct3D:    0/4 (retail)
DirectDraw:  0/4 (retail)
DirectInput: 0/5 (retail)
DirectMusic: 0/5 (retail)
DirectPlay:  0/9 (retail)
DirectSound: 0/5 (retail)
DirectShow:  0/6 (retail)

---------------
Display Devices
---------------
          Card name: Mobile Intel(R) 965 Express Chipset Family
       Manufacturer: Intel Corporation
          Chip type: Mobile Intel(R) 965 Express Chipset Family
           DAC type: Internal
         Device Key: Enum\PCI\VEN_8086&DEV_2A02&SUBSYS_01211025&REV_03
     Display Memory: 358 MB
   Dedicated Memory: 0 MB
      Shared Memory: 358 MB
       Current Mode: 1280 x 800 (32 bit) (60Hz)
       Monitor Name: Generic PnP Monitor
      Monitor Model: unknown
         Monitor Id: SEC3945
        Native Mode: 1280 x 800(p) (60.004Hz)
        Output Type: Internal
        Driver Name: igdumdx32.dll,igd10umd32.dll
Driver File Version: 8.14.0010.1930 (English)
     Driver Version: 8.15.10.1930
        DDI Version: 10
       Driver Model: WDDM 1.1
  Driver Attributes: Final Retail
   Driver Date/Size: 9/23/2009 19:14:54, 536576 bytes
        WHQL Logo'd: Yes
    WHQL Date Stamp: 
  Device Identifier: {D7B78E66-6942-11CF-1F74-2B21A2C2C535}
          Vendor ID: 0x8086
          Device ID: 0x2A02
          SubSys ID: 0x01211025
        Revision ID: 0x0003
 Driver Strong Name: oem2.inf:Intel.Mfg:i965GM0:8.15.10.1930:pci\ven_8086&dev_2a02
     Rank Of Driver: 00EC2001
        Video Accel: ModeMPEG2_A ModeMPEG2_C ModeWMV9_B ModeVC1_B 
   Deinterlace Caps: {BF752EF6-8CC4-457A-BE1B-08BD1CAEEE9F}: Format(In/Out)=(YUY2,YUY2) Frames(Prev/Fwd/Back)=(0,0,1) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_EdgeFiltering 
                     {335AA36E-7884-43A4-9C91-7F87FAF3E37E}: Format(In/Out)=(YUY2,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_BOBVerticalStretch 
                     {5A54A0C9-C7EC-4BD9-8EDE-F3C75DC4393B}: Format(In/Out)=(YUY2,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend 
                     {BF752EF6-8CC4-457A-BE1B-08BD1CAEEE9F}: Format(In/Out)=(UYVY,YUY2) Frames(Prev/Fwd/Back)=(0,0,1) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_EdgeFiltering 
                     {335AA36E-7884-43A4-9C91-7F87FAF3E37E}: Format(In/Out)=(UYVY,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_BOBVerticalStretch 
                     {5A54A0C9-C7EC-4BD9-8EDE-F3C75DC4393B}: Format(In/Out)=(UYVY,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend 
                     {BF752EF6-8CC4-457A-BE1B-08BD1CAEEE9F}: Format(In/Out)=(YV12,YUY2) Frames(Prev/Fwd/Back)=(0,0,1) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_EdgeFiltering 
                     {335AA36E-7884-43A4-9C91-7F87FAF3E37E}: Format(In/Out)=(YV12,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_BOBVerticalStretch 
                     {5A54A0C9-C7EC-4BD9-8EDE-F3C75DC4393B}: Format(In/Out)=(YV12,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend 
                     {BF752EF6-8CC4-457A-BE1B-08BD1CAEEE9F}: Format(In/Out)=(NV12,YUY2) Frames(Prev/Fwd/Back)=(0,0,1) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_EdgeFiltering 
                     {335AA36E-7884-43A4-9C91-7F87FAF3E37E}: Format(In/Out)=(NV12,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_BOBVerticalStretch 
                     {5A54A0C9-C7EC-4BD9-8EDE-F3C75DC4393B}: Format(In/Out)=(NV12,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend 
                     {BF752EF6-8CC4-457A-BE1B-08BD1CAEEE9F}: Format(In/Out)=(IMC1,YUY2) Frames(Prev/Fwd/Back)=(0,0,1) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_EdgeFiltering 
                     {335AA36E-7884-43A4-9C91-7F87FAF3E37E}: Format(In/Out)=(IMC1,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_BOBVerticalStretch 
                     {5A54A0C9-C7EC-4BD9-8EDE-F3C75DC4393B}: Format(In/Out)=(IMC1,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend 
                     {BF752EF6-8CC4-457A-BE1B-08BD1CAEEE9F}: Format(In/Out)=(IMC2,YUY2) Frames(Prev/Fwd/Back)=(0,0,1) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_EdgeFiltering 
                     {335AA36E-7884-43A4-9C91-7F87FAF3E37E}: Format(In/Out)=(IMC2,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_BOBVerticalStretch 
                     {5A54A0C9-C7EC-4BD9-8EDE-F3C75DC4393B}: Format(In/Out)=(IMC2,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend 
                     {BF752EF6-8CC4-457A-BE1B-08BD1CAEEE9F}: Format(In/Out)=(IMC3,YUY2) Frames(Prev/Fwd/Back)=(0,0,1) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_EdgeFiltering 
                     {335AA36E-7884-43A4-9C91-7F87FAF3E37E}: Format(In/Out)=(IMC3,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_BOBVerticalStretch 
                     {5A54A0C9-C7EC-4BD9-8EDE-F3C75DC4393B}: Format(In/Out)=(IMC3,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend 
                     {BF752EF6-8CC4-457A-BE1B-08BD1CAEEE9F}: Format(In/Out)=(IMC4,YUY2) Frames(Prev/Fwd/Back)=(0,0,1) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_EdgeFiltering 
                     {335AA36E-7884-43A4-9C91-7F87FAF3E37E}: Format(In/Out)=(IMC4,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend DeinterlaceTech_BOBVerticalStretch 
                     {5A54A0C9-C7EC-4BD9-8EDE-F3C75DC4393B}: Format(In/Out)=(IMC4,YUY2) Frames(Prev/Fwd/Back)=(0,0,0) Caps=VideoProcess_YUV2RGB VideoProcess_StretchX VideoProcess_StretchY VideoProcess_AlphaBlend 
       D3D9 Overlay: Not Supported
            DXVA-HD: Not Supported
       DDraw Status: Enabled
         D3D Status: Enabled
         AGP Status: Enabled

-------------
Sound Devices
-------------
            Description: Speakers (Realtek High Definition Audio)
 Default Sound Playback: Yes
 Default Voice Playback: Yes
            Hardware ID: HDAUDIO\FUNC_01&VEN_10EC&DEV_0888&SUBSYS_10250121&REV_1001
        Manufacturer ID: 1
             Product ID: 100
                   Type: WDM
            Driver Name: RTKVHDA.sys
         Driver Version: 6.00.0001.5901 (English)
      Driver Attributes: Final Retail
            WHQL Logo'd: Yes
          Date and Size: 7/23/2009 17:56:12, 2737248 bytes
            Other Files: 
        Driver Provider: Realtek Semiconductor Corp.
         HW Accel Level: Basic
              Cap Flags: 0xF1F
    Min/Max Sample Rate: 100, 200000
Static/Strm HW Mix Bufs: 1, 0
 Static/Strm HW 3D Bufs: 0, 0
              HW Memory: 0
       Voice Management: No
 EAX(tm) 2.0 Listen/Src: No, No
   I3DL2(tm) Listen/Src: No, No
Sensaura(tm) ZoomFX(tm): No

            Description: Realtek HDMI Output (Realtek High Definition Audio)
 Default Sound Playback: No
 Default Voice Playback: No
            Hardware ID: HDAUDIO\FUNC_01&VEN_10EC&DEV_0888&SUBSYS_10250121&REV_1001
        Manufacturer ID: 1
             Product ID: 100
                   Type: WDM
            Driver Name: RTKVHDA.sys
         Driver Version: 6.00.0001.5901 (English)
      Driver Attributes: Final Retail
            WHQL Logo'd: Yes
          Date and Size: 7/23/2009 17:56:12, 2737248 bytes
            Other Files: 
        Driver Provider: Realtek Semiconductor Corp.
         HW Accel Level: Basic
              Cap Flags: 0xF1F
    Min/Max Sample Rate: 100, 200000
Static/Strm HW Mix Bufs: 1, 0
 Static/Strm HW 3D Bufs: 0, 0
              HW Memory: 0
       Voice Management: No
 EAX(tm) 2.0 Listen/Src: No, No
   I3DL2(tm) Listen/Src: No, No
Sensaura(tm) ZoomFX(tm): No

            Description: Realtek Digital Output (Realtek High Definition Audio)
 Default Sound Playback: No
 Default Voice Playback: No
            Hardware ID: HDAUDIO\FUNC_01&VEN_10EC&DEV_0888&SUBSYS_10250121&REV_1001
        Manufacturer ID: 1
             Product ID: 100
                   Type: WDM
            Driver Name: RTKVHDA.sys
         Driver Version: 6.00.0001.5901 (English)
      Driver Attributes: Final Retail
            WHQL Logo'd: Yes
          Date and Size: 7/23/2009 17:56:12, 2737248 bytes
            Other Files: 
        Driver Provider: Realtek Semiconductor Corp.
         HW Accel Level: Basic
              Cap Flags: 0xF1F
    Min/Max Sample Rate: 100, 200000
Static/Strm HW Mix Bufs: 1, 0
 Static/Strm HW 3D Bufs: 0, 0
              HW Memory: 0
       Voice Management: No
 EAX(tm) 2.0 Listen/Src: No, No
   I3DL2(tm) Listen/Src: No, No
Sensaura(tm) ZoomFX(tm): No

---------------------
Sound Capture Devices
---------------------
            Description: Microphone (Realtek High Definition Audio)
  Default Sound Capture: Yes
  Default Voice Capture: Yes
            Driver Name: RTKVHDA.sys
         Driver Version: 6.00.0001.5901 (English)
      Driver Attributes: Final Retail
          Date and Size: 7/23/2009 17:56:12, 2737248 bytes
              Cap Flags: 0x1
           Format Flags: 0xFFFFF

-------------------
DirectInput Devices
-------------------
      Device Name: Mouse
         Attached: 1
    Controller ID: n/a
Vendor/Product ID: n/a
        FF Driver: n/a

      Device Name: Keyboard
         Attached: 1
    Controller ID: n/a
Vendor/Product ID: n/a
        FF Driver: n/a

      Device Name: Microsoft eHome Infrared Transceiver
         Attached: 1
    Controller ID: 0x0
Vendor/Product ID: 0x045E, 0x006D
        FF Driver: n/a

      Device Name: Microsoft eHome Infrared Transceiver
         Attached: 1
    Controller ID: 0x0
Vendor/Product ID: 0x045E, 0x006D
        FF Driver: n/a

      Device Name: Microsoft eHome Infrared Transceiver
         Attached: 1
    Controller ID: 0x0
Vendor/Product ID: 0x045E, 0x006D
        FF Driver: n/a

      Device Name: Microsoft eHome Infrared Transceiver
         Attached: 1
    Controller ID: 0x0
Vendor/Product ID: 0x045E, 0x006D
        FF Driver: n/a

      Device Name: Generic   USB  Joystick  
         Attached: 1
    Controller ID: 0x0
Vendor/Product ID: 0x1345, 0x1000
        FF Driver: n/a

Poll w/ Interrupt: No

-----------
USB Devices
-----------
+ USB Root Hub
| Vendor/Product ID: 0x8086, 0x2832
| Matching Device ID: usb\root_hub
| Service: usbhub
| Driver: usbhub.sys, 8/18/2015 00:51:18, 258560 bytes
| Driver: usbd.sys, 8/18/2015 00:51:18, 6016 bytes

----------------
Gameport Devices
----------------

------------
PS/2 Devices
------------
+ Standard PS/2 Keyboard
| Matching Device ID: *pnp0303
| Service: i8042prt
| Driver: i8042prt.sys, 7/14/2009 02:11:24, 80896 bytes
| Driver: kbdclass.sys, 7/14/2009 04:20:36, 42576 bytes
| 
+ Microsoft eHome Remote Control Keyboard keys
| Matching Device ID: hid\irdevicev2&col05
| Service: kbdhid
| Driver: kbdhid.sys, 11/21/2010 00:29:03, 28160 bytes
| Driver: kbdclass.sys, 7/14/2009 04:20:36, 42576 bytes
| 
+ Microsoft eHome MCIR Keyboard
| Matching Device ID: hid\irdevicev2&col06
| Service: kbdhid
| Driver: kbdhid.sys, 11/21/2010 00:29:03, 28160 bytes
| Driver: kbdclass.sys, 7/14/2009 04:20:36, 42576 bytes
| 
+ Microsoft eHome MCIR 109 Keyboard
| Matching Device ID: hid\irdevicev2&col07
| Service: kbdhid
| Driver: kbdhid.sys, 11/21/2010 00:29:03, 28160 bytes
| Driver: kbdclass.sys, 7/14/2009 04:20:36, 42576 bytes
| 
+ Terminal Server Keyboard Driver
| Matching Device ID: root\rdp_kbd
| Upper Filters: kbdclass
| Service: TermDD
| Driver: i8042prt.sys, 7/14/2009 02:11:24, 80896 bytes
| Driver: kbdclass.sys, 7/14/2009 04:20:36, 42576 bytes
| 
+ Synaptics PS/2 Port TouchPad
| Matching Device ID: *syn1b03
| Upper Filters: SynTP
| Service: i8042prt
| 
+ HID-compliant mouse
| Matching Device ID: hid_device_system_mouse
| Service: mouhid
| Driver: mouhid.sys, 7/14/2009 02:45:08, 26112 bytes
| Driver: mouclass.sys, 7/14/2009 04:20:44, 41552 bytes
| 
+ HID-compliant mouse
| Vendor/Product ID: 0x04F3, 0x0235
| Matching Device ID: hid_device_system_mouse
| Service: mouhid
| Driver: mouhid.sys, 7/14/2009 02:45:08, 26112 bytes
| Driver: mouclass.sys, 7/14/2009 04:20:44, 41552 bytes
| 
+ Terminal Server Mouse Driver
| Matching Device ID: root\rdp_mou
| Upper Filters: mouclass
| Service: TermDD
| Driver: termdd.sys, 11/21/2010 00:29:03, 53120 bytes
| Driver: sermouse.sys, 7/14/2009 02:45:08, 19968 bytes
| Driver: mouclass.sys, 7/14/2009 04:20:44, 41552 bytes

------------------------
Disk & DVD/CD-ROM Drives
------------------------
      Drive: C:
 Free Space: 14.2 GB
Total Space: 114.5 GB
File System: NTFS
      Model: Hitachi HTS542512K9SA00

      Drive: D:
      Model: TSSTcorp CDDVDW TS-L632H ATA Device
     Driver: c:\windows\system32\drivers\cdrom.sys, 6.01.7601.17514 (Lithuanian), 11/21/2010 00:29:03, 108544 bytes

--------------
System Devices
--------------
     Name: Mobile Intel(R) PM965/GM965/GL960/GS965 Express Processor to DRAM Controller - 2A00
Device ID: PCI\VEN_8086&DEV_2A00&SUBSYS_01211025&REV_03\3&21436425&0&00
   Driver: n/a

     Name: Intel(R) ICH8 Family USB2 Enhanced Host Controller - 2836
Device ID: PCI\VEN_8086&DEV_2836&SUBSYS_01211025&REV_03\3&21436425&0&EF
   Driver: C:\Windows\system32\drivers\usbehci.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 43520 bytes
   Driver: C:\Windows\system32\drivers\usbport.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 284672 bytes
   Driver: C:\Windows\system32\drivers\usbhub.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 258560 bytes

     Name: Intel(R) 82801 PCI Bridge - 2448
Device ID: PCI\VEN_8086&DEV_2448&SUBSYS_00000000&REV_F3\3&21436425&0&F0
   Driver: C:\Windows\system32\DRIVERS\pci.sys, 6.01.7601.17514 (English), 11/21/2010 00:29:03, 153984 bytes

     Name: Intel(R) ICH8M Ultra ATA Storage Controllers - 2850
Device ID: PCI\VEN_8086&DEV_2850&SUBSYS_01211025&REV_03\3&21436425&0&F9
   Driver: C:\Windows\system32\DRIVERS\intelide.sys, 6.01.7600.16385 (English), 7/14/2009 04:20:36, 15424 bytes
   Driver: C:\Windows\system32\DRIVERS\pciidex.sys, 6.01.7600.16385 (Lithuanian), 7/14/2009 04:19:03, 42560 bytes
   Driver: C:\Windows\system32\DRIVERS\atapi.sys, 6.01.7600.16385 (English), 7/14/2009 04:26:15, 21584 bytes
   Driver: C:\Windows\system32\DRIVERS\ataport.sys, 6.01.7601.18231 (Lithuanian), 8/18/2015 00:51:05, 133056 bytes

     Name: Intel(R) ICH8 Family USB Universal Host Controller - 2835
Device ID: PCI\VEN_8086&DEV_2835&SUBSYS_01211025&REV_03\3&21436425&0&D1
   Driver: C:\Windows\system32\drivers\usbuhci.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 24064 bytes
   Driver: C:\Windows\system32\drivers\usbport.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 284672 bytes
   Driver: C:\Windows\system32\drivers\usbhub.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 258560 bytes

     Name: Broadcom NetLink (TM) Gigabit Ethernet
Device ID: PCI\VEN_14E4&DEV_1693&SUBSYS_01211025&REV_02\4&1D1097F2&0&00E5
   Driver: n/a

     Name: High Definition Audio Controller
Device ID: PCI\VEN_8086&DEV_284B&SUBSYS_01211025&REV_03\3&21436425&0&D8
   Driver: C:\Windows\system32\DRIVERS\hdaudbus.sys, 6.01.7601.17514 (English), 11/21/2010 00:29:03, 108544 bytes

     Name: Intel(R) ICH8 Family USB Universal Host Controller - 2834
Device ID: PCI\VEN_8086&DEV_2834&SUBSYS_01211025&REV_03\3&21436425&0&D0
   Driver: C:\Windows\system32\drivers\usbuhci.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 24064 bytes
   Driver: C:\Windows\system32\drivers\usbport.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 284672 bytes
   Driver: C:\Windows\system32\drivers\usbhub.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 258560 bytes

     Name: Ricoh xD-Picture Card Controller
Device ID: PCI\VEN_1180&DEV_0852&SUBSYS_01211025&REV_12\4&6AD4B7A&0&4CF0
   Driver: C:\Windows\system32\DRIVERS\rixdptsk.sys, 6.00.0001.0000 (Japanese), 11/14/2006 17:35:20, 37376 bytes
   Driver: C:\Windows\system32\rixdicon.dll, 5/6/2005 19:06:00, 16480 bytes

     Name: Intel(R) ICH8 Family PCI Express Root Port 6 - 2849
Device ID: PCI\VEN_8086&DEV_2849&SUBSYS_01211025&REV_03\3&21436425&0&E5
   Driver: C:\Windows\system32\DRIVERS\pci.sys, 6.01.7601.17514 (English), 11/21/2010 00:29:03, 153984 bytes

     Name: Intel(R) ICH8 Family USB Universal Host Controller - 2832
Device ID: PCI\VEN_8086&DEV_2832&SUBSYS_01211025&REV_03\3&21436425&0&EA
   Driver: C:\Windows\system32\drivers\usbuhci.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 24064 bytes
   Driver: C:\Windows\system32\drivers\usbport.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 284672 bytes
   Driver: C:\Windows\system32\drivers\usbhub.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 258560 bytes

     Name: Ricoh SD/MMC Host Controller
Device ID: PCI\VEN_1180&DEV_0843&SUBSYS_01211025&REV_12\4&6AD4B7A&0&4AF0
   Driver: C:\Windows\system32\DRIVERS\rimmptsk.sys, 6.00.0002.0003 (Japanese), 2/24/2007 15:42:22, 39936 bytes

     Name: Intel(R) ICH8 Family PCI Express Root Port 4 - 2845
Device ID: PCI\VEN_8086&DEV_2845&SUBSYS_01211025&REV_03\3&21436425&0&E3
   Driver: C:\Windows\system32\DRIVERS\pci.sys, 6.01.7601.17514 (English), 11/21/2010 00:29:03, 153984 bytes

     Name: Intel(R) ICH8 Family USB Universal Host Controller - 2831
Device ID: PCI\VEN_8086&DEV_2831&SUBSYS_01211025&REV_03\3&21436425&0&E9
   Driver: C:\Windows\system32\drivers\usbuhci.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 24064 bytes
   Driver: C:\Windows\system32\drivers\usbport.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 284672 bytes
   Driver: C:\Windows\system32\drivers\usbhub.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 258560 bytes

     Name: Ricoh 1394 OHCI Compliant Host Controller
Device ID: PCI\VEN_1180&DEV_0832&SUBSYS_01211025&REV_05\4&6AD4B7A&0&48F0
   Driver: C:\Windows\system32\DRIVERS\1394ohci.sys, 6.01.7601.17514 (English), 11/21/2010 00:29:03, 164864 bytes

     Name: Intel(R) PRO/Wireless 3945ABG Network Connection
Device ID: PCI\VEN_8086&DEV_4222&SUBSYS_10018086&REV_02\4&10F04939&0&00E3
   Driver: n/a

     Name: Intel(R) ICH8 Family PCI Express Root Port 1 - 283F
Device ID: PCI\VEN_8086&DEV_283F&SUBSYS_01211025&REV_03\3&21436425&0&E0
   Driver: C:\Windows\system32\DRIVERS\pci.sys, 6.01.7601.17514 (English), 11/21/2010 00:29:03, 153984 bytes

     Name: Intel(R) ICH8 Family USB Universal Host Controller - 2830
Device ID: PCI\VEN_8086&DEV_2830&SUBSYS_01211025&REV_03\3&21436425&0&E8
   Driver: C:\Windows\system32\drivers\usbuhci.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 24064 bytes
   Driver: C:\Windows\system32\drivers\usbport.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 284672 bytes
   Driver: C:\Windows\system32\drivers\usbhub.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 258560 bytes

     Name: SDA Standard Compliant SD Host Controller
Device ID: PCI\VEN_1180&DEV_0822&SUBSYS_01211025&REV_22\4&6AD4B7A&0&49F0
   Driver: C:\Windows\system32\DRIVERS\sdbus.sys, 6.01.7601.17514 (English), 11/21/2010 00:29:03, 84992 bytes

     Name: Mobile Intel(R) 965 Express Chipset Family
Device ID: PCI\VEN_8086&DEV_2A03&SUBSYS_01211025&REV_03\3&21436425&0&11
   Driver: n/a

     Name: Intel(R) ICH8 Family SMBus Controller - 283E
Device ID: PCI\VEN_8086&DEV_283E&SUBSYS_01211025&REV_03\3&21436425&0&FB
   Driver: n/a

     Name: Intel(R) 82801HEM/HBM SATA AHCI Controller
Device ID: PCI\VEN_8086&DEV_2829&SUBSYS_01211025&REV_03\3&21436425&0&FA
   Driver: C:\Windows\system32\DRIVERS\iaStor.sys, 7.00.0001.1001 (English), 10/30/2007 15:05:00, 277784 bytes

     Name: Ricoh Memory Stick Controller
Device ID: PCI\VEN_1180&DEV_0592&SUBSYS_01211025&REV_12\4&6AD4B7A&0&4BF0
   Driver: C:\Windows\system32\snymsico.dll, 1.00.0000.9120 (English), 9/4/2004 04:00:00, 90112 bytes
   Driver: C:\Windows\system32\DRIVERS\rimsptsk.sys, 6.00.0001.0010 (Japanese), 1/23/2007 17:40:20, 42496 bytes

     Name: Mobile Intel(R) 965 Express Chipset Family
Device ID: PCI\VEN_8086&DEV_2A02&SUBSYS_01211025&REV_03\3&21436425&0&10
   Driver: C:\Windows\system32\DRIVERS\igdkmd32.sys, 8.14.0010.1930 (English), 9/23/2009 19:18:14, 4808192 bytes
   Driver: C:\Windows\system32\igdumd32.dll, 8.14.0010.1930 (English), 9/23/2009 19:18:08, 3829760 bytes
   Driver: C:\Windows\system32\igkrng400.bin, 9/23/2009 19:16:08, 2050952 bytes
   Driver: C:\Windows\system32\iglhxs32.vp, 9/23/2009 19:45:20, 39440 bytes
   Driver: C:\Windows\system32\iglhxo32.vp, 9/23/2009 18:45:12, 60015 bytes
   Driver: C:\Windows\system32\iglhxc32.vp, 9/23/2009 18:45:12, 60226 bytes
   Driver: C:\Windows\system32\iglhxg32.vp, 9/23/2009 18:45:12, 60254 bytes
   Driver: C:\Windows\system32\iglhxa32.vp, 9/23/2009 18:45:12, 1090 bytes
   Driver: C:\Windows\system32\iglhxa32.cpa, 9/23/2009 18:45:12, 1921265 bytes
   Driver: C:\Windows\system32\hccutils.dll, 8.14.0010.1930 (English), 9/23/2009 18:49:04, 94208 bytes
   Driver: C:\Windows\system32\igfxsrvc.dll, 8.14.0010.1930 (English), 9/23/2009 18:49:24, 51712 bytes
   Driver: C:\Windows\system32\igfxsrvc.exe, 8.14.0010.1930 (English), 9/23/2009 12:30:48, 252952 bytes
   Driver: C:\Windows\system32\igfxpph.dll, 8.14.0010.1930 (English), 9/23/2009 18:49:42, 199680 bytes
   Driver: C:\Windows\system32\igfxcpl.cpl, 8.14.0010.1930 (English), 9/23/2009 18:49:34, 119296 bytes
   Driver: C:\Windows\system32\igfxcfg.exe, 8.14.0010.1930 (English), 9/23/2009 12:30:50, 672792 bytes
   Driver: C:\Windows\system32\igfxdev.dll, 8.14.0010.1930 (English), 9/23/2009 18:49:00, 218112 bytes
   Driver: C:\Windows\system32\igfxdo.dll, 8.14.0010.1930 (English), 9/23/2009 18:49:10, 130048 bytes
   Driver: C:\Windows\system32\igfxtray.exe, 8.14.0010.1930 (English), 9/23/2009 12:30:48, 141848 bytes
   Driver: C:\Windows\system32\hkcmd.exe, 8.14.0010.1930 (English), 9/23/2009 12:30:48, 173592 bytes
   Driver: C:\Windows\system32\igfxress.dll, 8.14.0010.1930 (English), 9/23/2009 18:48:52, 5702656 bytes
   Driver: C:\Windows\system32\igfxpers.exe, 8.14.0010.1930 (English), 9/23/2009 12:30:48, 150552 bytes
   Driver: C:\Windows\system32\igfxTMM.dll, 8.14.0010.1930 (English), 9/23/2009 18:49:42, 257536 bytes
   Driver: C:\Windows\system32\TVWSetup.exe, 1.00.0001.0000 (English), 9/23/2009 12:30:50, 8198680 bytes
   Driver: C:\Windows\system32\igfxext.exe, 8.14.0010.1930 (English), 9/23/2009 12:30:48, 173080 bytes
   Driver: C:\Windows\system32\igfxexps.dll, 8.14.0010.1930 (English), 9/23/2009 18:49:36, 23552 bytes
   Driver: C:\Windows\system32\oemdspif.dll, 8.14.0010.1930 (English), 9/23/2009 18:49:38, 59392 bytes
   Driver: C:\Windows\system32\igfxrara.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:08, 252416 bytes
   Driver: C:\Windows\system32\igfxrchs.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:10, 178176 bytes
   Driver: C:\Windows\system32\igfxrcht.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:10, 179712 bytes
   Driver: C:\Windows\system32\igfxrdan.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:10, 280576 bytes
   Driver: C:\Windows\system32\igfxrdeu.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:10, 303616 bytes
   Driver: C:\Windows\system32\igfxrenu.lrc, 8.14.0010.1930 (English), 9/23/2009 18:48:52, 275968 bytes
   Driver: C:\Windows\system32\igfxresp.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:12, 303104 bytes
   Driver: C:\Windows\system32\igfxrfin.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:12, 281088 bytes
   Driver: C:\Windows\system32\igfxrfra.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:12, 303616 bytes
   Driver: C:\Windows\system32\igfxrheb.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:14, 249856 bytes
   Driver: C:\Windows\system32\igfxrita.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:14, 304640 bytes
   Driver: C:\Windows\system32\igfxrjpn.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:14, 206848 bytes
   Driver: C:\Windows\system32\igfxrkor.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:14, 205312 bytes
   Driver: C:\Windows\system32\igfxrnld.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:16, 299520 bytes
   Driver: C:\Windows\system32\igfxrnor.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:16, 280064 bytes
   Driver: C:\Windows\system32\igfxrplk.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:16, 287744 bytes
   Driver: C:\Windows\system32\igfxrptb.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:16, 289280 bytes
   Driver: C:\Windows\system32\igfxrptg.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:18, 294912 bytes
   Driver: C:\Windows\system32\igfxrrus.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:18, 291328 bytes
   Driver: C:\Windows\system32\igfxrsky.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:18, 282624 bytes
   Driver: C:\Windows\system32\igfxrslv.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:18, 277504 bytes
   Driver: C:\Windows\system32\igfxrsve.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:18, 282624 bytes
   Driver: C:\Windows\system32\igfxrtha.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:20, 262656 bytes
   Driver: C:\Windows\system32\igfxrcsy.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:10, 282624 bytes
   Driver: C:\Windows\system32\igfxrell.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:12, 310784 bytes
   Driver: C:\Windows\system32\igfxrhun.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:14, 288256 bytes
   Driver: C:\Windows\system32\igfxrtrk.lrc, 8.14.0010.1930 (English), 9/23/2009 18:52:20, 279040 bytes
   Driver: C:\Windows\system32\ig4icd32.dll, 8.14.0010.1930 (English), 9/23/2009 18:58:12, 4104192 bytes
   Driver: C:\Windows\system32\ig4dev32.dll, 8.14.0010.1930 (English), 9/23/2009 18:58:38, 2686976 bytes
   Driver: C:\Windows\system32\igd10umd32.dll, 8.14.0010.1930 (English), 9/23/2009 19:09:58, 2551808 bytes
   Driver: C:\Windows\system32\igdumdx32.dll, 8.14.0010.1930 (English), 9/23/2009 19:14:54, 536576 bytes
   Driver: C:\Windows\system32\igfxCoIn_v1930.dll, 1.01.0017.0000 (English), 9/23/2009 19:27:44, 155648 bytes

     Name: Intel(R) ICH8 Family USB2 Enhanced Host Controller - 283A
Device ID: PCI\VEN_8086&DEV_283A&SUBSYS_01211025&REV_03\3&21436425&0&D7
   Driver: C:\Windows\system32\drivers\usbehci.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 43520 bytes
   Driver: C:\Windows\system32\drivers\usbport.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 284672 bytes
   Driver: C:\Windows\system32\drivers\usbhub.sys, 6.01.7601.18328 (English), 8/18/2015 00:51:18, 258560 bytes

     Name: Intel(R) ICH8M LPC Interface Controller - 2815
Device ID: PCI\VEN_8086&DEV_2815&SUBSYS_01211025&REV_03\3&21436425&0&F8
   Driver: C:\Windows\system32\DRIVERS\msisadrv.sys, 6.01.7600.16385 (English), 7/14/2009 04:20:43, 13888 bytes

------------------
DirectShow Filters
------------------

DirectShow Filters:
WMAudio Decoder DMO,0x00800800,1,1,WMADMOD.DLL,6.01.7601.17514
WMAPro over S/PDIF DMO,0x00600800,1,1,WMADMOD.DLL,6.01.7601.17514
WMSpeech Decoder DMO,0x00600800,1,1,WMSPDMOD.DLL,6.01.7601.17514
MP3 Decoder DMO,0x00600800,1,1,mp3dmod.dll,6.01.7600.16385
Mpeg4s Decoder DMO,0x00800001,1,1,mp4sdecd.dll,6.01.7600.16385
WMV Screen decoder DMO,0x00600800,1,1,wmvsdecd.dll,6.01.7601.17514
WMVideo Decoder DMO,0x00800001,1,1,wmvdecod.dll,6.01.7601.18221
Mpeg43 Decoder DMO,0x00800001,1,1,mp43decd.dll,6.01.7600.16385
Mpeg4 Decoder DMO,0x00800001,1,1,mpg4decd.dll,6.01.7600.16385
ffdshow Video Decoder,0xff800001,2,1,ffdshow.ax,1.03.4534.0000
ffdshow raw video filter,0x00200000,2,1,ffdshow.ax,1.03.4534.0000
ffdshow Audio Decoder,0xff800001,1,1,ffdshow.ax,1.03.4534.0000
DV Muxer,0x00400000,0,0,qdv.dll,6.06.7601.17514
Color Space Converter,0x00400001,1,1,quartz.dll,6.06.7601.18741
LAV Splitter,0x00400001,1,1,LAVSplitter.ax,0.65.0000.0047
WM ASF Reader,0x00400000,0,0,qasf.dll,12.00.7601.17514
Screen Capture filter,0x00200000,0,1,wmpsrcwp.dll,12.00.7601.17514
AVI Splitter,0x00600000,1,1,quartz.dll,6.06.7601.18741
VGA 16 Color Ditherer,0x00400000,1,1,quartz.dll,6.06.7601.18741
SBE2MediaTypeProfile,0x00200000,0,0,sbe.dll,6.06.7601.17528
Microsoft DTV-DVD Video Decoder,0x005fffff,2,4,msmpeg2vdec.dll,12.00.9200.17037
AC3 Parser Filter,0x00600000,1,1,mpg2splt.ax,6.06.7601.17528
StreamBufferSink,0x00200000,0,0,sbe.dll,6.06.7601.17528
Microsoft TV Captions Decoder,0x00200001,1,0,MSTVCapn.dll,6.01.7601.17715
MJPEG Decompressor,0x00600000,1,1,quartz.dll,6.06.7601.18741
CBVA DMO wrapper filter,0x00200000,1,1,cbva.dll,6.01.7601.17514
MPEG-I Stream Splitter,0x00600000,1,2,quartz.dll,6.06.7601.18741
SAMI (CC) Parser,0x00400000,1,1,quartz.dll,6.06.7601.18741
VBI Codec,0x00600000,1,4,VBICodec.ax,6.06.7601.17514
MPEG-2 Splitter,0x005fffff,1,0,mpg2splt.ax,6.06.7601.17528
Closed Captions Analysis Filter,0x00200000,2,5,cca.dll,6.06.7601.17514
SBE2FileScan,0x00200000,0,0,sbe.dll,6.06.7601.17528
Microsoft MPEG-2 Video Encoder,0x00200000,1,1,msmpeg2enc.dll,6.01.7601.17514
Internal Script Command Renderer,0x00800001,1,0,quartz.dll,6.06.7601.18741
MPEG Audio Decoder,0x03680001,1,1,quartz.dll,6.06.7601.18741
DV Splitter,0x00600000,1,2,qdv.dll,6.06.7601.17514
Video Mixing Renderer 9,0x00200000,1,0,quartz.dll,6.06.7601.18741
Microsoft MPEG-2 Encoder,0x00200000,2,1,msmpeg2enc.dll,6.01.7601.17514
ACM Wrapper,0x00600000,1,1,quartz.dll,6.06.7601.18741
Video Renderer,0x00800001,1,0,quartz.dll,6.06.7601.18741
MPEG-2 Video Stream Analyzer,0x00200000,0,0,sbe.dll,6.06.7601.17528
Line 21 Decoder,0x00600000,1,1,qdvd.dll,6.06.7601.18741
Video Port Manager,0x00600000,2,1,quartz.dll,6.06.7601.18741
Video Renderer,0x00400000,1,0,quartz.dll,6.06.7601.18741
VPS Decoder,0x00200000,0,0,WSTPager.ax,6.06.7601.17514
WM ASF Writer,0x00400000,0,0,qasf.dll,12.00.7601.17514
VBI Surface Allocator,0x00600000,1,1,vbisurf.ax,6.01.7601.17514
File writer,0x00200000,1,0,qcap.dll,6.06.7601.17514
iTV Data Sink,0x00600000,1,0,itvdata.dll,6.06.7601.17514
Bandisoft MPEG-1 Video Decoder,0xff800001,1,1,bdfilters.dll,1.00.0005.0016
iTV Data Capture filter,0x00600000,1,1,itvdata.dll,6.06.7601.17514
VSFilter,0x00200000,2,1,vsfilter.dll,1.07.0009.0145
VSFilter (auto-loading version),0x00800002,2,1,vsfilter.dll,1.07.0009.0145
DVD Navigator,0x00200000,0,3,qdvd.dll,6.06.7601.18741
Microsoft TV Subtitles Decoder,0x00200001,1,0,MSTVCapn.dll,6.01.7601.17715
Overlay Mixer2,0x00200000,1,1,qdvd.dll,6.06.7601.18741
AVI Draw,0x00600064,9,1,quartz.dll,6.06.7601.18741
RDP DShow Redirection Filter,0xffffffff,1,0,DShowRdpFilter.dll,
DC-Bass Source,0x00400000,0,1,DCBassSourceMod.ax,1.05.0002.0000
Microsoft MPEG-2 Audio Encoder,0x00200000,1,1,msmpeg2enc.dll,6.01.7601.17514
WST Pager,0x00200000,1,1,WSTPager.ax,6.06.7601.17514
MPEG-2 Demultiplexer,0x00600000,1,1,mpg2splt.ax,6.06.7601.17528
DV Video Decoder,0x00800000,1,1,qdv.dll,6.06.7601.17514
ffdshow Audio Processor,0x00200000,1,1,ffdshow.ax,1.03.4534.0000
LAV Splitter Source,0x00400001,0,1,LAVSplitter.ax,0.65.0000.0047
SampleGrabber,0x00200000,1,1,qedit.dll,6.06.7601.18501
Null Renderer,0x00200000,1,0,qedit.dll,6.06.7601.18501
MPEG-2 Sections and Tables,0x005fffff,1,0,Mpeg2Data.ax,6.06.7601.17514
Microsoft AC3 Encoder,0x00200000,1,1,msac3enc.dll,6.01.7601.17514
StreamBufferSource,0x00200000,0,0,sbe.dll,6.06.7601.17528
Smart Tee,0x00200000,1,2,qcap.dll,6.06.7601.17514
Overlay Mixer,0x00200000,0,0,qdvd.dll,6.06.7601.18741
AVI Decompressor,0x00600000,1,1,quartz.dll,6.06.7601.18741
NetBridge,0x00200000,2,0,netbridge.dll,6.01.7601.17514
AVI/WAV File Source,0x00400000,0,2,quartz.dll,6.06.7601.18741
Wave Parser,0x00400000,1,1,quartz.dll,6.06.7601.18741
MIDI Parser,0x00400000,1,1,quartz.dll,6.06.7601.18741
Multi-file Parser,0x00400000,1,1,quartz.dll,6.06.7601.18741
File stream renderer,0x00400000,1,1,quartz.dll,6.06.7601.18741
ffdshow subtitles filter,0x00200000,2,1,ffdshow.ax,1.03.4534.0000
Microsoft DTV-DVD Audio Decoder,0x005fffff,1,1,msmpeg2adec.dll,6.01.7140.0000
StreamBufferSink2,0x00200000,0,0,sbe.dll,6.06.7601.17528
AVI Mux,0x00200000,1,0,qcap.dll,6.06.7601.17514
Bandisoft MPEG-1 Audio Decoder,0xff800001,1,1,bdfilters.dll,1.00.0005.0016
Line 21 Decoder 2,0x00600002,1,1,quartz.dll,6.06.7601.18741
File Source (Async.),0x00400000,0,1,quartz.dll,6.06.7601.18741
File Source (URL),0x00400000,0,1,quartz.dll,6.06.7601.18741
Media Center Extender Encryption Filter,0x00200000,2,2,Mcx2Filter.dll,6.01.7601.17514
AudioRecorder WAV Dest,0x00200000,0,0,WavDest.dll,
AudioRecorder Wave Form,0x00200000,0,0,WavDest.dll,
SoundRecorder Null Renderer,0x00200000,0,0,WavDest.dll,
LAV Audio Decoder,0x00800003,1,1,LAVAudio.ax,0.65.0000.0047
LAV Video Decoder,0xff800000,1,1,LAVVideo.ax,0.65.0000.0047
Infinite Pin Tee Filter,0x00200000,1,1,qcap.dll,6.06.7601.17514
Enhanced Video Renderer,0x00200000,1,0,evr.dll,6.01.7601.18741
BDA MPEG2 Transport Information Filter,0x00200000,2,0,psisrndr.ax,6.06.7601.17669
MPEG Video Decoder,0x40000001,1,1,quartz.dll,6.06.7601.18741

WDM Streaming Tee/Splitter Devices:
Tee/Sink-to-Sink Converter,0x00200000,1,1,ksproxy.ax,6.01.7601.17514

Video Compressors:
WMVideo8 Encoder DMO,0x00600800,1,1,wmvxencd.dll,6.01.7600.16385
WMVideo9 Encoder DMO,0x00600800,1,1,wmvencod.dll,6.01.7600.16385
MSScreen 9 encoder DMO,0x00600800,1,1,wmvsencd.dll,6.01.7600.16385
DV Video Encoder,0x00200000,0,0,qdv.dll,6.06.7601.17514
ffdshow video encoder,0x00100000,1,1,ffdshow.ax,1.03.4534.0000
MJPEG Compressor,0x00200000,0,0,quartz.dll,6.06.7601.18741
Cinepak Codec by Radius,0x00200000,1,1,qcap.dll,6.06.7601.17514
Intel IYUV codec,0x00200000,1,1,qcap.dll,6.06.7601.17514
Intel IYUV codec,0x00200000,1,1,qcap.dll,6.06.7601.17514
Bandi MJPEG Video Decoder,0x00200000,1,1,qcap.dll,6.06.7601.17514
Bandi MPEG-1 Video Decoder,0x00200000,1,1,qcap.dll,6.06.7601.17514
Microsoft RLE,0x00200000,1,1,qcap.dll,6.06.7601.17514
Microsoft Video 1,0x00200000,1,1,qcap.dll,6.06.7601.17514

Audio Compressors:
WM Speech Encoder DMO,0x00600800,1,1,WMSPDMOE.DLL,6.01.7600.16385
WMAudio Encoder DMO,0x00600800,1,1,WMADMOE.DLL,6.01.7600.16385
IMA ADPCM,0x00200000,1,1,quartz.dll,6.06.7601.18741
PCM,0x00200000,1,1,quartz.dll,6.06.7601.18741
Microsoft ADPCM,0x00200000,1,1,quartz.dll,6.06.7601.18741
GSM 6.10,0x00200000,1,1,quartz.dll,6.06.7601.18741
CCITT A-Law,0x00200000,1,1,quartz.dll,6.06.7601.18741
CCITT u-Law,0x00200000,1,1,quartz.dll,6.06.7601.18741
MP2,0x00200000,1,1,quartz.dll,6.06.7601.18741
MPEG Layer-3,0x00200000,1,1,quartz.dll,6.06.7601.18741

Audio Capture Sources:
Microphone (Realtek High Defini,0x00200000,0,0,qcap.dll,6.06.7601.17514

PBDA CP Filters:
PBDA DTFilter,0x00600000,1,1,CPFilters.dll,6.06.7601.17528
PBDA ETFilter,0x00200000,0,0,CPFilters.dll,6.06.7601.17528
PBDA PTFilter,0x00200000,0,0,CPFilters.dll,6.06.7601.17528

Midi Renderers:
Default MidiOut Device,0x00800000,1,0,quartz.dll,6.06.7601.18741
Microsoft GS Wavetable Synth,0x00200000,1,0,quartz.dll,6.06.7601.18741

WDM Streaming Capture Devices:
,0x00000000,0,0,,
,0x00000000,0,0,,
,0x00000000,0,0,,
Acer CrystalEye webcam,0x00200000,1,2,ksproxy.ax,6.01.7601.17514

WDM Streaming Rendering Devices:
Realtek HD Audio output,0x00200000,1,1,ksproxy.ax,6.01.7601.17514
Realtek HDA HDMI Out,0x00200000,1,1,ksproxy.ax,6.01.7601.17514
Realtek HDA SPDIF Out,0x00200000,1,1,ksproxy.ax,6.01.7601.17514

BDA Network Providers:
Microsoft ATSC Network Provider,0x00200000,0,1,MSDvbNP.ax,6.06.7601.17514
Microsoft DVBC Network Provider,0x00200000,0,1,MSDvbNP.ax,6.06.7601.17514
Microsoft DVBS Network Provider,0x00200000,0,1,MSDvbNP.ax,6.06.7601.17514
Microsoft DVBT Network Provider,0x00200000,0,1,MSDvbNP.ax,6.06.7601.17514
Microsoft Network Provider,0x00200000,0,1,MSNP.ax,6.06.7601.17514

Video Capture Sources:
Acer CrystalEye webcam,0x00200000,1,2,ksproxy.ax,6.01.7601.17514

Multi-Instance Capable VBI Codecs:
VBI Codec,0x00600000,1,4,VBICodec.ax,6.06.7601.17514

BDA Transport Information Renderers:
BDA MPEG2 Transport Information Filter,0x00600000,2,0,psisrndr.ax,6.06.7601.17669
MPEG-2 Sections and Tables,0x00600000,1,0,Mpeg2Data.ax,6.06.7601.17514

BDA CP/CA Filters:
Decrypt/Tag,0x00600000,1,1,EncDec.dll,6.06.7601.17708
Encrypt/Tag,0x00200000,0,0,EncDec.dll,6.06.7601.17708
PTFilter,0x00200000,0,0,EncDec.dll,6.06.7601.17708
XDS Codec,0x00200000,0,0,EncDec.dll,6.06.7601.17708

WDM Streaming Communication Transforms:
Tee/Sink-to-Sink Converter,0x00200000,1,1,ksproxy.ax,6.01.7601.17514

Audio Renderers:
Speakers (Realtek High Definiti,0x00200000,1,0,quartz.dll,6.06.7601.18741
Default DirectSound Device,0x00800000,1,0,quartz.dll,6.06.7601.18741
Default WaveOut Device,0x00200000,1,0,quartz.dll,6.06.7601.18741
DirectSound: Realtek Digital Output (Realtek High Definition Audio),0x00200000,1,0,quartz.dll,6.06.7601.18741
DirectSound: Realtek HDMI Output (Realtek High Definition Audio),0x00200000,1,0,quartz.dll,6.06.7601.18741
DirectSound: Speakers (Realtek High Definition Audio),0x00200000,1,0,quartz.dll,6.06.7601.18741
Realtek Digital Output (Realtek,0x00200000,1,0,quartz.dll,6.06.7601.18741
Realtek HDMI Output (Realtek Hi,0x00200000,1,0,quartz.dll,6.06.7601.18741

---------------
EVR Power Information
---------------
Current Setting: {5C67A112-A4C9-483F-B4A7-1D473BECAFDC} (Quality) 
  Quality Flags: 2576
    Enabled:
    Force throttling
    Allow half deinterlace
    Allow scaling
    Decode Power Usage: 100
  Balanced Flags: 1424
    Enabled:
    Force throttling
    Allow batching
    Force half deinterlace
    Force scaling
    Decode Power Usage: 50
  PowerFlags: 1424
    Enabled:
    Force throttling
    Allow batching
    Force half deinterlace
    Force scaling
    Decode Power Usage: 0
